package com.mpt.Helper;

import java.util.ArrayList;
import java.util.Iterator;

import com.mpt.Bean.BookSchema;

public class BookCollectionHelper 
{
	private static ArrayList<BookSchema> bookList=null;
	static
	{
		
		//creating objects for BookSchema to store book data
		bookList= new ArrayList<BookSchema>();
		BookSchema b1=new BookSchema(100,"Noor Mohammed",100);
		BookSchema b2=new BookSchema(101,"Ranganath",101);
		BookSchema b3=new BookSchema(102,"Karthik",102);
		//adding values into the Collection
		bookList.add(b1);
		bookList.add(b2);
		bookList.add(b3);
	}
	public void addNewBookDetails(BookSchema book)
	{
		bookList.add(book);
	}
	public static ArrayList<BookSchema> getBookList()
	{
		return bookList;
	}
	public static void setBookList(ArrayList<BookSchema> bookList)
	{
		BookCollectionHelper.bookList= bookList;
	}
	public static void displayBookCount()
	{
		Iterator<BookSchema> bookIt=bookList.iterator();
		BookSchema tempBook=null;
		int totalCount=0;
		while(bookIt.hasNext())
		{
			totalCount++;
			tempBook=bookIt.next();
			System.out.println(tempBook);
		}
		System.out.println("Total Number of Books are: "+totalCount);
	}
	
}
