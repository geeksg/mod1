package com.mpt.Helper;
import java.util.regex.Pattern;
import com.mpt.Exception.BookException;

public class BookDataValidator 
{
	public static boolean validatebookId(String bookId)throws BookException
	{
		String IdPattern="\\d{3}";
		if(Pattern.matches(IdPattern, bookId))
		{
			return true;
		}
		else
		{
			throw new BookException("Enter Only Three digit Book ID.");
		}
	}
	public static boolean validatebookName(String bookName)throws BookException
	{
		String IdPattern="^[A-Z][A-Za-z]{5,20}";
		if(Pattern.matches(IdPattern, bookName))
		{
			return true;
		}
		else
		{
			throw new BookException("Book Name should contain only characters having first letter capital and should have minimum lenghth 6 and maximum length 20. ");
		}
	}
	public static boolean validatebookPrice(String bookPrice)throws BookException
	{
		String IdPattern="\\d{2,4}.?[0-9]{2}$";
		if(Pattern.matches(IdPattern, bookPrice))
		{
			return true;
		}
		else
		{
			throw new BookException("Incorrect Price. Enter (2-4) digits before decimal and enter 2 digits after decimal.");
		}
	}
}
