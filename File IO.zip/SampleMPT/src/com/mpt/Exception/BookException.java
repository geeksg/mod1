package com.mpt.Exception;

public class BookException extends Exception 
{
	//private static 
	public BookException(String message)
	{
		super(message);
	}
}

