package com.mpt.Helper;
import java.util.regex.Pattern;
import com.mpt.Exception.BookException;

public class BookDataValidator 
{
	public static boolean validatebookId(String bookId)throws BookException
	{
		String IdPattern="\\d{3}";
		if(Pattern.matches(IdPattern, bookId))
		{
			return true;
		}
		else
		{
			throw new BookException("OnlY three digit Id is allowed");
		}
	}
	public static boolean validatebookName(String bookName)throws BookException
	{
		String IdPattern="[A-Za-z]{6,20}";
		if(Pattern.matches(IdPattern, bookName))
		{
			return true;
		}
		else
		{
			throw new BookException("OnlY characters and numbers are allowed");
		}
	}
	public static boolean validatebookPrice(String bookPrice)throws BookException
	{
		String IdPattern="\\d{1,6}";
		if(Pattern.matches(IdPattern, bookPrice))
		{
			return true;
		}
		else
		{
			throw new BookException("Only numbers are allowed");
		}
	}
}
