package com.mpt.Ui;
import java.util.Scanner;

import com.mpt.Bean.BookSchema;
import com.mpt.Exception.BookException;
import com.mpt.Helper.BookCollectionHelper;
import com.mpt.Helper.BookDataValidator;

public class BookUi 
{
	static Scanner sc= new Scanner(System.in);
	static BookCollectionHelper collectionhelper=null;
	@SuppressWarnings("static-access")
	public static void main(String[] args) 
	{
		int choice=0;
		collectionhelper = new BookCollectionHelper();
		while(true)
		{
			System.out.println("1.Add New Book\n2.Find Total Count Of Books\n3.Exit");
			System.out.println("Enter Your Choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: enterNewBookDetails();
				break;
			case 2: BookCollectionHelper.displayBookCount();
				break;
			default: System.exit(0);
			}
		}
	}
	public static void enterNewBookDetails()
	{
		System.out.println("How many books? ");
		int bcount=sc.nextInt();
		while(bcount!=0)
		{
			System.out.println("Enter Book Id: ");
			String bookId=sc.next();
			try
			{
				if(BookDataValidator.validatebookId(bookId))
				{
					System.out.println("Enter Book Name: ");
					String bookName=sc.next();
					if(BookDataValidator.validatebookName(bookName))
					{
						System.out.println("Enter Book Price: ");
						String bookPrice=sc.next();
						if(BookDataValidator.validatebookPrice(bookPrice))
						{
							BookSchema book=new BookSchema(Integer.parseInt(bookId),bookName,Double.parseDouble(bookPrice));
							collectionhelper.addNewBookDetails(book);
						}
					}
				}
			}
			catch (Exception e)
			{
				System.out.println(e.getMessage());
			}
			bcount--;
		}

	}
}
