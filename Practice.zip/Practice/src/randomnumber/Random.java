package randomnumber;
import java.util.*;
public class Random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Random rn= new Random();
		for( int i=0;i<10;i++){
			int answer = rn.nextInt(10)+1;
	System.out.println(answer);
}
	}

	private int nextInt(int i) {
		// TODO Auto-generated method stub
		return 0;
	}
}
