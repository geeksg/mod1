package lesson7;
interface printable{
	void print();
}
public class TestInterface1 implements printable{
public void print(){System.out.println("Hello");}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestInterface1 obj = new TestInterface1();
		obj.print();

	}

}
