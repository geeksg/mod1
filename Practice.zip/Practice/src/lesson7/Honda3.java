package lesson7;
abstract class Bike{
	abstract void run();
}

public class Honda3 extends Bike{
void run() {
	System.out.println("running safely.."); 
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bike obj=new Honda3();
obj.run();
	}

}
