package lesson5;
import java.util.Date;
public class currentdate_time {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Date date = new Date();
System.out.println(date.toString());
	}

}
