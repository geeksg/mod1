package lesson5;

public class exactequals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str1="Hello";
String str2= new String(str1);
System.out.println(str1 + " equals " + str2 + " -> " + str1.equals(str2));
System.out.println(str1 + " == " + str2 + " -> " + (str1));
	}

}
