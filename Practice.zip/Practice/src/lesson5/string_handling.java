package lesson5;

public class string_handling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String string="Core";
System.out.println( string=string.concat("Java"));
String s="Core" + "Java";
System.out.println(s);
String a= "string";int b=3; int c=7;
System.out.println(a + b + c);
System.out.println(a + (b + c));
	}

}
