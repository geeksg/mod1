package lesson5;

public class Implicit_automatic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 100;
long l = a;
float f = a;
System.out.println("Int value "+a);
System.out.println("Long value "+l);
System.out.println("Float value "+f);
	}

}
