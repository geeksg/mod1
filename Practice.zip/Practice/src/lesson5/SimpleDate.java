package lesson5;
import java.text.SimpleDateFormat;
import java.util.Date;
public class SimpleDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Date dNow= new Date();
SimpleDateFormat ft = new SimpleDateFormat("E YYYY.MM.DD 'at' hh:mm:ss a zzz");
System.out.println("Current Date: " + ft.format(dNow));
	}

}
