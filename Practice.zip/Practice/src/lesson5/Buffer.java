package lesson5;

public class Buffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBuffer buffer= new StringBuffer("hello");
buffer.append("java");
System.out.println(buffer);
	}

}
