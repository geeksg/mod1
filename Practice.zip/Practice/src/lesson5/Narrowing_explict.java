package lesson5;

public class Narrowing_explict {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double d = 100.04;
long l = (long)d;
int i = (int)l;
System.out.println("Double value "+d);
System.out.println("Long value "+l);
System.out.println("Int value "+i);
	}

}
