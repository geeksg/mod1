package lesson5;

public class Builder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder bf= new StringBuilder("hello");
		bf.append("java");
		System.out.println(bf);
	}

}
