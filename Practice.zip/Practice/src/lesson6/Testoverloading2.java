package lesson6;
class Addition{
	static int add(int a,int b){return a+b;}
	static double add(double a,double b){return a + b;}
}
public class Testoverloading2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Addition.add(14,17));
		System.out.println(Addition.add(13.3,14.6));
	}

}
