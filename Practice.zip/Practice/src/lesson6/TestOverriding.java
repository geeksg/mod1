package lesson6;
class Bank {
int	getRateOfInterest(){ return 0;}
}
class SBI extends Bank{
	int	getRateOfInterest(){ return 8;}
}
	class Kotak extends Bank{
		int	getRateOfInterest(){ return 7;}
		
	}
	class UPI extends Bank{
			int	getRateOfInterest(){ return 9;}	
	}
public class TestOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SBI s = new SBI();
Kotak k = new Kotak();
UPI u = new UPI();
System.out.println("SBI Rate of Interest: "+s.getRateOfInterest());
System.out.println("Kotak Rate of Interest: "+k.getRateOfInterest());
System.out.println("UPI Rate of Interest: "+u.getRateOfInterest());

	}
}