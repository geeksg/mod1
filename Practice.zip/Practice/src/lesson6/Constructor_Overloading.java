package lesson6;

public class Constructor_Overloading {
	Constructor_Overloading (){
		
	}
	Constructor_Overloading(double dblValue){
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor_Overloading Obj1 = new Constructor_Overloading();
		Constructor_Overloading Obj2 = new Constructor_Overloading();
	}

}
