package lesson6;
class Base {
	public void baseMethod()
	{
		System.out.println("Base");
	}
}
class Derived extends Base{
	public void derivedMethod()
	{
		super.baseMethod();
		System.out.println("Derived");
	}
}
public class UsingSuperKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Derived d= new Derived();
d.derivedMethod();
	}

}
