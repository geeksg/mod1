package lesson6;

public class InstOff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
InstOff s= new InstOff();
System.out.println(s instanceof InstOff);
	}

}
