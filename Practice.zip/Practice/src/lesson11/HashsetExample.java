package lesson11;
import java.util.*;
public class HashsetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> set=new HashSet<String>();
		set.add("Mannu");
		set.add("Leo");
		set.add("Eswar");
		set.add("Leo");
		Iterator<String> itr=set.iterator();
		while (itr.hasNext())
		{
			System.out.println(itr.next());
	}

}
}