package lesson11;
import java.util.*;
public class Vector1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Vector<String> v=new Vector<String>();
v.add("Leo");
v.addElement("Sony");
v.addElement("Mony");
v.add("Leo");
Enumeration e=v.elements();
while(e.hasMoreElements()){
	System.out.println(e.nextElement());
}
	}

}
