package lesson11;

import java.util.*;

public class HashMapexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> h=new HashMap<Integer,String>();
		h.put(120,"Mannu");
		h.put(100,"Leo");
		h.put(200,"Eswar");
		h.put(300,"Leo");
		for(Map.Entry m:h.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue());
	}
	}

}
