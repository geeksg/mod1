package lesson11;

import java.util.*;


public class Treesetexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> set=new TreeSet<String>();
		set.add("Mannu");
		set.add("Leo");
		set.add("Eswar");
		set.add("Leo");
		Iterator<String> itr=set.iterator();
		while (itr.hasNext())
		{
			System.out.println(itr.next());
	}
	}

}
