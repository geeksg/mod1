package lesson11;
import java.util.*;
public class CollectionHashTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<Integer,String> hm=new Hashtable<Integer,String>();
		hm.put(150,"Mannu");
		hm.put(400,"Leo");
		hm.put(200,"Eswar");
		hm.put(300,"Leo");
		for(Map.Entry m:hm.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue());
	}
	}

}
