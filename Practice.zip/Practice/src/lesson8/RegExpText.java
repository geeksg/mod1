package lesson8;
import java.util.regex.*;
public class RegExpText {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String inputString="Test String";
String pattern="Test String";
boolean patternMatched = pattern.matches("pattern,inputString");
System.out.println(patternMatched);
	}

}
