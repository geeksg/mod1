package lesson8;
import java.util.regex.*;
public class RegExpTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Pattern.matches("[amn]", "abcd"));
		System.out.println(Pattern.matches(".[amn]", "a"));
	}

}
