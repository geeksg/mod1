package junitdemos;
import org.junit.*;
import org.junit.Test;
import org.junit.After;

public class demo3 {
@BeforeClass
public static void init(){
System.out.println("BeforeClass");
}
@Before
public void initalize(){
System.out.println("Before");
}
@Test
public  void MyTestMethodone(){
System.out.println("Test1");
}
@Test
public  void MyTestMethodTwo(){
System.out.println("Test2");
}
@Ignore
@Test
public  void MyTestMethod(){
System.out.println("Test1");
}
@After
public  void close(){
System.out.println("After");
}
@AfterClass
public static void closeresource(){
System.out.println("AfterClass");
}
}
