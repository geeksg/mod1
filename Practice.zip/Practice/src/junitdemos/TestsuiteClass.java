package junitdemos;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
@RunWith(Suite.class)
@Suite.SuiteClasses({demo1.class,demo3.class,demo2.class})
public class TestsuiteClass {

}
