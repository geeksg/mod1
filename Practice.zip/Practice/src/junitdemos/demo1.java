package junitdemos;
import org.junit.Before;
import org.junit.Test;
import org.junit.After;
public class demo1 {
@Before
public void initialize(){
	System.out.println("Before");
}
@Test
public void myTestmethod(){
	System.out.println("Test");
}	
@After
public void close(){
	System.out.println("After");
}
}
