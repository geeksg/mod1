package junitdemos;
import org.junit.*;
import org.junit.Test;
import org.junit.After;
public class demo2 {

	@Test
public void b(){
	System.out.println("TestMethod1");
}

	@Test
public void a(){
	System.out.println("TestMethod2");
}

	@AfterClass
public static void closeresources(){
	System.out.println("Afterclass");
}
}
