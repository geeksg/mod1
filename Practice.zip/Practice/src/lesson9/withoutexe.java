package lesson9;

public class withoutexe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int data=50/0;
System.out.println("rest of the code..... ");
	}

}
