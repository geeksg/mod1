package com.mpt.Junit;

import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.mpt.Bean.BookSchema;
import com.mpt.Exception.BookException;
import com.mpt.Helper.BookCollectionHelper;

public class BookCollectionHelperTest {
	static BookCollectionHelper collectionHelper;
	static BookSchema book=null;
	
	@BeforeClass
	public static void beforeClass()
	{
		collectionHelper=new BookCollectionHelper();
		book= new BookSchema(888,"Java Black Book",670.65);
	}
	@AfterClass
	public static void afterClass()
	{
		collectionHelper=null;
		book=null;
	}
	@Test
	public void testAddNewBook() throws BookException
	{
		collectionHelper.addNewBookDetails(book);
		//Assert.assertEquals(4,collectionHelper.getBookList().size());
		Assert.assertNotNull(collectionHelper.toString());
		
	}
}
