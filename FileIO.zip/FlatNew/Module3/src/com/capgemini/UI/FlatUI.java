package com.capgemini.UI;

import java.util.Random;
import java.util.Scanner;

import com.capgemini.flats.bean.FlatDetails;
import com.capgemini.Exception.FlatException;
import com.capgemini.flats.service.FlatHelper;
import com.capgemini.flats.service.FlatValidator;

public class FlatUI {

	static Scanner sc=new Scanner(System.in);
	static FlatHelper Flathelper=null;
	
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice=0;
		Flathelper=new FlatHelper();
		
		while(true)
		{
			System.out.println("1:New Flat Registration \n"+
					"2:Calculate Maintenance Cost \n3:Exit");

			System.out.println("\nEnter Your Choice: ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	enterNewFlatDetails();break;
			case 2: FlatHelper.displayFlatCount();break;
			default:System.exit(0);			
			}
		}
	}
	
	private static void enterNewFlatDetails() 
	{
		int maximum=400;
		int minimum=3;
		Random randomFlat=new Random();
		int flat_ID= randomFlat.nextInt();
			try 
		{
			if(FlatValidator.validateflatId(flat_ID))
			System.out.println("Enter name:");
			String Name=sc.next();
			if(FlatValidator.validateFName(Name))
			{
				System.out.println("Enter Mobile Number ");
				String Mobileno =sc.next();
			
			if(FlatValidator.validateMobileNumber(Mobileno))
						{
					System.out.println("Enter Tower Number ");
					String Towerno =sc.next();
						
			if(FlatValidator.validateTowerNumber(Towerno))
							{
						System.out.println("Enter Flat Size(Sq.Ft) ");
						String Flatsize =sc.next();
						if(FlatValidator.validateFlatSize(Integer.parseInt(Flatsize))){
						FlatDetails flat=new FlatDetails(Integer.parseInt(flat_ID),Name,Mobileno,Towerno,Integer.parseInt(Flatsize));
						Flathelper.addNewFlatDetails(flat);
						System.out.print("New flat Registered with FlatID"+flat_ID);
				}	
		
							}
						}
		}
	}
		catch (FlatException e)
		{			
			System.out.println(e.getMessage());
		}
}
		
	}
	
	

