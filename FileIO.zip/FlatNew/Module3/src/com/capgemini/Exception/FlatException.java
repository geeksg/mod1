package com.capgemini.Exception;

public class FlatException extends Exception {
	private static final long serialVersionUID = 1L;
	public FlatException()
	{
		super();
	}
	public FlatException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public FlatException(String message, Throwable cause) 
	{
		super(message, cause);
	}
	public FlatException(String message) 
	{
		super(message);			
	}
	public FlatException(Throwable cause) 
	{
		super(cause);			
	} 
}