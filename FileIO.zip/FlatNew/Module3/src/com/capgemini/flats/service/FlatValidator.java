package com.capgemini.flats.service;
import java.util.regex.Pattern;

import com.capgemini.Exception.FlatException;
public class FlatValidator {

	public  static  boolean validateFName(String FName)throws FlatException
	{
		String custPattern="[a-z]{5,15}";
		if(Pattern.matches(custPattern, FName))
		{
			return true;
		}
		else
		{
			throw new FlatException("Name should have Min 5 and Max 15 characters Allowed");
		}
	}
	
	public  static  boolean validateMobileNumber(String mobileNo)throws FlatException
	{
		String MobileNo="[789]{1}[0-9]{9}";
		if(Pattern.matches(MobileNo, mobileNo))
		{
			return true;
		}
		else
		{
			throw new FlatException("MobileNumber should contains 10-digit number starting with either 7/8/9.");
		}
	}
	
	public  static  boolean validateTowerNumber(String TowerNo)throws FlatException
	{

		String Towerno="[1-25]+";
		if(Pattern.matches(Towerno,TowerNo))
		{
			return true;
		}
		else
		{
			throw new FlatException("TowerNo should be between 1 to 25");
		}
	}
		
	public  static  boolean validateFlatSize(int FlatSize)throws FlatException
	{
		String SizePattern="\\d{3}{4}";
		if(Pattern.matches(SizePattern,Integer.toString(FlatSize)))
		{
			return true;
		}
		else
		{
			throw new FlatException("Flat Size should be 3-digits or 4-digits only.");
		}
	}
	
}


