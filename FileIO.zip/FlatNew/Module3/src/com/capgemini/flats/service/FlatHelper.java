package com.capgemini.flats.service;
import java.util.HashSet;
import java.util.Iterator;

import com.capgemini.flats.bean.FlatDetails;
public class FlatHelper {

	private  static HashSet<FlatDetails> FlatList=null;
	static
	//Adding Flats
	{
	
		FlatList=new HashSet<FlatDetails>();
		
		FlatDetails f1=new FlatDetails(1, "Samuel","9872612345","23",670,2*670);
		FlatDetails f2=new FlatDetails(2,"Amala","8288866678","12",1200,2*1200);
		
		FlatList.add(f1);
		FlatList.add(f2);
	
	}
public FlatHelper(){}
	
	/*************Add New Flat in HashSet************/
	public void addNewFlatDetails(FlatDetails Flat) 
	{			
			FlatList.add(Flat);				
	}
	
	public static HashSet<FlatDetails> getFlatList() {
		return FlatList;
	}

	public static void setFlatList(HashSet<FlatDetails> FlatList) {
		FlatHelper.FlatList = FlatList;
	}

	
	/*************Fetch All Flat Details ***********/

	public static  void displayFlatCount()
	{
		Iterator<FlatDetails> FlatIt=FlatList.iterator();
		FlatDetails tempFlat=null;
		
		int totalCount=0;
		while(FlatIt.hasNext())
		{
			totalCount++;
			tempFlat=FlatIt.next();
			System.out.println(tempFlat);			
		}
		System.out.println("Total Count of Flats" + totalCount);
	}
}
