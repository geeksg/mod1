package com.capgemini.flats.bean;

public class FlatDetails {
int flatID;
String fName;
String mobileNo;
String towerNo;
int flatSize;
double maintenancecost;

public FlatDetails() {
	super();
	// TODO Auto-generated constructor stub
} 

public FlatDetails(int flatID, String fName, String mobileNo, String towerNo,
		int flatSize, double maintenancecost) {
	super();
	this.flatID = flatID;
	this.fName = fName;
	this.mobileNo = mobileNo;
	this.towerNo = towerNo;
	this.flatSize = flatSize;
	this.maintenancecost = maintenancecost;
}

public int getFlatID() {
	return flatID;
}
public void setFlatID(int flatID) {
	this.flatID = flatID;
}
public String getfName() {
	return fName;
}
public void setfName(String fName) {
	this.fName = fName;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getTowerNo() {
	return towerNo;
}
public void setTowerNo(String towerNo) {
	this.towerNo = towerNo;
}
public int getFlatSize() {
	return flatSize;
}
public void setFlatSize(int flatSize) {
	this.flatSize = flatSize;
}
public double getMaintenancecost() {
	return maintenancecost;
}
public void setMaintenancecost(double maintenancecost) {
	this.maintenancecost = maintenancecost;
}
@Override
public String toString() {
	return "FlatDetails [flatID=" + flatID + ", fName=" + fName + ", mobileNo="
			+ mobileNo + ", towerNo=" + towerNo + ", flatSize=" + flatSize
			+ ", maintenancecost=" + maintenancecost + "]";
}

	

}
