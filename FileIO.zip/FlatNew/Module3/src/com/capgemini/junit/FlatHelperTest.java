package com.capgemini.junit;
import junit.framework.Assert;

import org.junit.Test;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.capgemini.flats.bean.FlatDetails;
import com.capgemini.Exception.FlatException;
import com.capgemini.flats.service.FlatHelper;
public class FlatHelperTest {

	static FlatHelper collectionHelper;
	static FlatDetails flatdetails=null;

	@BeforeClass
	public   static  void beforeClass()
	{
		collectionHelper=new FlatHelper();
		flatdetails = new FlatDetails(1,"Rahul","8256156777","18", 786,2*786);		
	}	
	@AfterClass
	public static  void afterClass()
	{		
		collectionHelper=null;
		flatdetails=null;
	}	


	@Test 
	public void testAddNewFlat() throws FlatException
	{
		collectionHelper.addNewFlatDetails(flatdetails);
		
		Assert.assertNotNull(collectionHelper.toString());

	}
	
	}