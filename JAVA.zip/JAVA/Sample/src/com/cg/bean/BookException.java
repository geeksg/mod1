package com.cg.bean;public class BookException extends Exception{

	public  BookException(String message)
	{
		super(message);
	}
} 

