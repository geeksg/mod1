package com.cg.bean;
class BookSchema
{
	private int bookId;
	private String bookName;
	private double bookPrice;
	public BookSchema(){}
	//creating constructor of book class
	public BookSchema(int bookId, String bookName, double bookPrice)
	{
		this.bookId=bookId;
		this.bookName=bookName;
		this.bookPrice=bookPrice;
	}
	public int getbookId()
	{
		return bookId;
	}
	public void setbookId(int bookId)
	{
	this.bookId=bookId;
	}
	public String getbookName()
	{
		return bookName;
	}
	public void setbookName(String bookName){
	this.bookName=bookName;
	}
	public double getbookPrice()
	{
		return bookPrice;
	}
	public void setbookPrice(double bookPrice){
	this.bookPrice=bookPrice;
	}
	
	//@override
	public String toString(){
		return "The book details are"+bookId+" " +bookName +" " +bookPrice+ " ";
	}


	


}
