package com.appli.Login;

final Democlass
{
	
}

public class FinalDemo {
	public static void main(String[] args) {
		final int a=30;
		Democlass d=new Democlass();
		d.Test1();
	}
}
