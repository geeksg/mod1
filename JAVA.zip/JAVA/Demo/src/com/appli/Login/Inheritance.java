package com.appli.Login;

class superclass{
	/*superclass()
	{
		System.out.println("Executing Super class constructor.");
	}*/
	public void Test1(){
		System.out.println("Executing Test 1");
	}
	public void Test2(){
		System.out.println("Executing Test 2");
	}
}
class subclass extends superclass{
	public void Test3(){
		super.Test1();
		System.out.println("Executing Test 3");
	}
}
class sub extends superclass{
	public void Test4(){
		super.Test1();
		super.Test2();
		System.out.println("Executing Test 4");
	}
}
public class Inheritance {
	public static void main(String[] args) {
		subclass sub= new subclass();
		sub s=new sub();
		sub.Test1();
		sub.Test2();
		sub.Test3();
		s.Test4();
	}

}
