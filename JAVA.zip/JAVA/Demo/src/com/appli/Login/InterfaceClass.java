package com.appli.Login;

interface Democlass
{
	public void Test1()
	{
		syso
	}
	public void Test2(){
		syso
	}
}

public class InterfaceClass implements Democlass {
	public static void main(String[] args) {
		
	}

}
