package com.appli.Login;

//import Scanner;

public class Scanner {
	public static void main(String[] args) {
		/*Scanner sc=new Scanner (System.in)
		int i = sc.next.Int();
		System.out.println("You entered: ");
		
	
a="String"; int b=3; int c=7;
System.out.println(a+());*/
		String str1="Hello";
		String str2="Hell";
		System.out.println(str1.equals(str2));
	}
}
