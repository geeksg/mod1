package com.appli.Login;

abstract class Demo
{
	abstract public void Test1();//abstract incomplete method
	
	public void Test2()//complete method
	{
		System.out.println("Test 2 Method");
	}
}


public class Abstract extends Demo {
	public static void main(String[] args) {
		
	}
	public void Test1(){
		System.out.println("");
	}

}
