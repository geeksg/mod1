package com.appli.Login;

public class Exception {
	public static void main(String[] args) {
		int a=10;
		int b=5;
 		String str=null;
		try{
		int c=a/b;
		str.equals("Hello");
		}
		/*catch(NullPointerException e){
			System.out.println("It is a null value.");
			System.out.println(e.getMessage());
		}*/
		 
		
		//Another code(divided by zero)
		
		//int a=10;
		//int b=5;
		//try{
		//	 int c=a/b;
			 		
		// }
		/*catch(ArithmeticException x){
			System.out.println(x.getMessage());
			System.out.println("Value divided by Zero");
		}*/
		
		//array Index Out of bound Exception
		
		//int[] arr = new int[2];
		//try{
		//	arr[3]=10;
		//}
		/*catch(ArrayIndexOutOfBoundsException d){
			
			System.out.println(d.getMessage());
		}*/
		
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
	}

	
		
}

