package com.appli.Login;

public class MethodOverloading {
	public static void main(String[] args) {
		MethodOverloading md= new MethodOverloading();
		md.Test1(9.5,5.3);
	}
	void Test1(int a,double b)
	{
		System.out.println(" The 1st decimal value is "+a+" and 2nd decimal value is "+b);
	}
	void Test1(double a,int b)
	{
		System.out.println(" The 1st decimal value is "+a+" and 2nd integer value is "+b);
	}
	void Test1(int a, int b)
	{
		System.out.println(" The 1st integer value is "+a+" and 2nd integer value is "+b);
	} 
	void Test1(double a, double b)
	{
		System.out.println(" The 1st decimal value is "+a+" and 2nd decimal value is "+b);
	}
}