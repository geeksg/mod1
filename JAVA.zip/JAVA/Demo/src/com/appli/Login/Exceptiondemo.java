package com.appli.Login;
import java.lang.*;
public class Exceptiondemo {
public static void main(String[] args) {
		
 		/*String str=null;
		try {
		
		} catch (Exception a) {
			// TODO: handle exception
		}
		}
		/*catch(NullPointerException e){
			System.out.println("It is a null value.");
			System.out.println(e.getMessage());
		}*/
		 
		
		//Another code(divided by zero)
		
		/*int a=10;
		int b=0;
		try{
			 int c=a/b;
		 }
		/*catch(ArithmeticException x){
			System.out.println(x.getMessage());
			System.out.println("Value divided by Zero");
		}*/
		
		//array Index Out of bound Exception
		
		int[] arr = new int[2];
		try {
			int a=10;
			int b=0;
			 int c=a/b;
		} catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
}}
		
		/*catch(ArrayIndexOutOfBoundsException d){
			
			System.out.println(d.getMessage());
		}*/
		

