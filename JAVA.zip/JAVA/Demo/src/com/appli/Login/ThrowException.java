package com.appli.Login;

import com.login.sahoo.ArithmaticException;

public class ThrowException {
	static void validate(int age) throws ArithmaticException{
		if(age<18)
		{
			throw new ArithmaticException("");
	}

	}
}
