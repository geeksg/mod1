package com.appli.Login;
class Book
{
	String name;
	String author;
	int price;
	//creating constructor of book class
	Book(String name, String author, int price)
	{
		this.name=name;
		this.author=author;
		this.price=price;
	}
	public String getname()
	{
		return name;
	}
	public void setname(String name)
	{
	this.name=name;
	}
	public String getauhtor()
	{
		return author;
	}
	public void setauthor(String author){
	this.author=author;
	}
	public int getprice()
	{
		return price;
	}
	public void setprice(int price){
	this.price=price;
	}
	
	public String toString(){
		return "The book details are"+name+" " +author +" " +price+ " ";
	}
}

public class ToString {
	public static void main(String[] args){
		Book bk = new Book("Selenium","Jesus",1000);
		System.out.println(bk);
	}

}
