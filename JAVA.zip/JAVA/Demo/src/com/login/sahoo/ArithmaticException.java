package com.login.sahoo;

public class ArithmaticException extends Exception
{
public  ArithmaticException(String message)
{
	System.out.println("jhsfdauyfgsdyfdgh");
}
}
